﻿use Pharamcy;
Alter table Medicine
add Foreign key(Supplier) references Supplier(SupplierId);