﻿
create table Supplier(
	SupplierId int Primary Key,
	SupplierName varchar(40),

);
create table Medicine(
	LotNo int Primary Key,
	MFDate varchar(20),
	EXPDate varchar(20),
	TabletName varchar(40),
	Dosage varchar(40),
	Supplier int,
	Foreign key(Supplier) references Supplier(SupplierId),
	Accesibility varchar(40),

);
