﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PharmacyManagement
{
    public partial class Form10 : Form
    {
        public Form10()
        {
            InitializeComponent();
        }

        private void btnOrderMed_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form14 loader = new Form14();
            loader.Show();

        }

        private void btnClientInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form11 loader = new Form11();
            loader.Show();
        }

        private void btnGetNew_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form12 loader = new Form12();
            loader.Show();
        }

        private void btnMedInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form13 loader = new Form13();
            loader.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loader = new Form1();
            loader.Show();
        }
    }
}
