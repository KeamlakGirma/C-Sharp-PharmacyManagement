﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PharmacyManagement
{

    public partial class Form2 : Form
    {
        
        public Form2()
        {
            InitializeComponent();
        }

        private void btnNewUser_Click(object sender, EventArgs e)
        {
            
            this.Hide();
            Form4 login = new Form4();
            login.Show();

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void btnEmpInfo_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form6 loader = new Form6();
            loader.Show();
        }

        private void btnAddNewEmp_Click(object sender, EventArgs e)
        {
            this.Hide();              
            Form5 loader = new Form5();
            loader.Show();
        }

        private void btnSuppliers_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form7 loader = new Form7();
            loader.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 loader = new Form1();
            loader.Show();
        }
    }
}
