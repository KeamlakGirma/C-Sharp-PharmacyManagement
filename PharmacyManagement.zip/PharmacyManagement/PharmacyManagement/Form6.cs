﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace PharmacyManagement
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }

        private void btnEmpIdCheck_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form8 loader = new Form8();
            loader.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 loader = new Form2();
            loader.Show();
        }
    }
}
