﻿
namespace PharmacyManagement
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtEmpIdCheck = new System.Windows.Forms.TextBox();
            this.btnEmpIdCheck = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(274, 46);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(224, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Admin view employee info";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(49, 137);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(307, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Enter Employee\'s Id You want to view";
            // 
            // txtEmpIdCheck
            // 
            this.txtEmpIdCheck.Location = new System.Drawing.Point(402, 131);
            this.txtEmpIdCheck.Name = "txtEmpIdCheck";
            this.txtEmpIdCheck.Size = new System.Drawing.Size(150, 31);
            this.txtEmpIdCheck.TabIndex = 2;
            // 
            // btnEmpIdCheck
            // 
            this.btnEmpIdCheck.Location = new System.Drawing.Point(513, 215);
            this.btnEmpIdCheck.Name = "btnEmpIdCheck";
            this.btnEmpIdCheck.Size = new System.Drawing.Size(112, 34);
            this.btnEmpIdCheck.TabIndex = 3;
            this.btnEmpIdCheck.Text = "View";
            this.btnEmpIdCheck.UseVisualStyleBackColor = true;
            this.btnEmpIdCheck.Click += new System.EventHandler(this.btnEmpIdCheck_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(70, 30);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Form6
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnEmpIdCheck);
            this.Controls.Add(this.txtEmpIdCheck);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form6";
            this.Text = "Form6";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtEmpIdCheck;
        private System.Windows.Forms.Button btnEmpIdCheck;
        private System.Windows.Forms.Button btnBack;
    }
}