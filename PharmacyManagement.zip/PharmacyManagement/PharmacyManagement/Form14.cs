﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PharmacyManagement
{
    public partial class Form14 : Form
    {
        public Form14()
        {
            InitializeComponent();

        }

        private void btnRestock_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-0HDH5VS\SQLEXPRESS;Initial Catalog=Pharamcy;Integrated Security=True");
            conn.Open();
            try
            {
                string sqlQ = "UPDATE Medicine SET NoInStock = 100 WHERE LotNo=txtLotNo.Text; ";
                SqlCommand sqlcmd = new SqlCommand(sqlQ, conn);
                sqlcmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("New User added", "Pharmacy Management System");
            }
            catch
            {
                MessageBox.Show("Invalid Info", "Pharmacy Management System");

            }
            
            this.Hide();
            Form1 loader = new Form1();
            loader.Show();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form10 loader = new Form10();
            loader.Show();
        }

        //MessageBox.Show("Restocked", "Pharmacy Management System");
    }
    }

