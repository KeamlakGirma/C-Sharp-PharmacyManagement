﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PharmacyManagement
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();

        
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
                
                this.Hide();
                Form1 loader = new Form1();
                loader.Show();
            
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-0HDH5VS\SQLEXPRESS;Initial Catalog=Pharamcy;Integrated Security=True");
            conn.Open();
            try
            {
                string sqlQ = "insert into Client values (" + txtClientId.Text + ",'" + txtFName.Text + "','" + txtLName.Text + "','" + txtAddress.Text + "','" + txtEmail.Text + "','" + txtAllergy.Text + "','" + txtPrescription.Text + "','" + txtUsername.Text + "');";
                SqlCommand sqlcmd = new SqlCommand(sqlQ, conn);
                sqlcmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("New User added", "Pharmacy Management System");
            }
            catch
            {
                MessageBox.Show("Invalid Info", "Pharmacy Management System");
                
            }
           
            this.Hide();
            Form1 loader = new Form1();
            loader.Show();
        }

        private void txtClientId_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
