﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PharmacyManagement
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form2 loader = new Form2();
            loader.Show();
        }

        private void lblUsername_Click(object sender, EventArgs e)
        {

        }

        private void txtUsername_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-0HDH5VS\SQLEXPRESS;Initial Catalog=Pharamcy;Integrated Security=True");
            conn.Open();
            try
            {
                string sqlQ = "insert into Employee values (" + txtEmpId.Text + ",'" + txtFName.Text + "','" + txtLName.Text + "','" + txtEmail.Text + "','" + txtAddress.Text + "','" + txtPosition.Text + "','" + txtStartDate.Text+ "');";
                SqlCommand sqlcmd = new SqlCommand(sqlQ, conn);
                sqlcmd.ExecuteNonQuery();
                conn.Close();
                MessageBox.Show("New User added", "Pharmacy Management System");
            }
            catch
            {
                MessageBox.Show("Invalid Info", "Pharmacy Management System");

            }

            this.Hide();
            Form1 loader = new Form1();
            loader.Show();
        }
    }
}
