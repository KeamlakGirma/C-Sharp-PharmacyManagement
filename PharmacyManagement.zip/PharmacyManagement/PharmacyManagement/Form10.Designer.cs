﻿
namespace PharmacyManagement
{
    partial class Form10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnClientInfo = new System.Windows.Forms.Button();
            this.btnRestockMed = new System.Windows.Forms.Button();
            this.btnMedInfo = new System.Windows.Forms.Button();
            this.btnGetNew = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(310, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Pharmacist View";
            // 
            // btnClientInfo
            // 
            this.btnClientInfo.Location = new System.Drawing.Point(35, 69);
            this.btnClientInfo.Name = "btnClientInfo";
            this.btnClientInfo.Size = new System.Drawing.Size(152, 34);
            this.btnClientInfo.TabIndex = 1;
            this.btnClientInfo.Text = "Get Client Info";
            this.btnClientInfo.UseVisualStyleBackColor = true;
            this.btnClientInfo.Click += new System.EventHandler(this.btnClientInfo_Click);
            // 
            // btnRestockMed
            // 
            this.btnRestockMed.Location = new System.Drawing.Point(35, 127);
            this.btnRestockMed.Name = "btnRestockMed";
            this.btnRestockMed.Size = new System.Drawing.Size(152, 34);
            this.btnRestockMed.TabIndex = 2;
            this.btnRestockMed.Text = "Restock Medicine";
            this.btnRestockMed.UseVisualStyleBackColor = true;
            this.btnRestockMed.Click += new System.EventHandler(this.btnOrderMed_Click);
            // 
            // btnMedInfo
            // 
            this.btnMedInfo.Location = new System.Drawing.Point(35, 253);
            this.btnMedInfo.Name = "btnMedInfo";
            this.btnMedInfo.Size = new System.Drawing.Size(192, 34);
            this.btnMedInfo.TabIndex = 3;
            this.btnMedInfo.Text = "Get Medicine Info";
            this.btnMedInfo.UseVisualStyleBackColor = true;
            this.btnMedInfo.Click += new System.EventHandler(this.btnMedInfo_Click);
            // 
            // btnGetNew
            // 
            this.btnGetNew.Location = new System.Drawing.Point(35, 190);
            this.btnGetNew.Name = "btnGetNew";
            this.btnGetNew.Size = new System.Drawing.Size(192, 34);
            this.btnGetNew.TabIndex = 4;
            this.btnGetNew.Text = "Add New Medicine";
            this.btnGetNew.UseVisualStyleBackColor = true;
            this.btnGetNew.Click += new System.EventHandler(this.btnGetNew_Click);
            // 
            // btnBack
            // 
            this.btnBack.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btnBack.Location = new System.Drawing.Point(12, 12);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(70, 30);
            this.btnBack.TabIndex = 7;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // Form10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.btnGetNew);
            this.Controls.Add(this.btnMedInfo);
            this.Controls.Add(this.btnRestockMed);
            this.Controls.Add(this.btnClientInfo);
            this.Controls.Add(this.label1);
            this.Name = "Form10";
            this.Text = "Form10";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClientInfo;
        private System.Windows.Forms.Button btnRestockMed;
        private System.Windows.Forms.Button btnMedInfo;
        private System.Windows.Forms.Button btnGetNew;
        private System.Windows.Forms.Button btnBack;
    }
}