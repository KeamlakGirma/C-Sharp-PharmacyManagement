﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PharmacyManagement
{
    public partial class Form1 : Form
    {
        public static string passer1;
        public static string passer2;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (txtuserName.Text == "admin" && txtPassword.Text == "1234")
            {
                this.Hide();
                Form2 loader = new Form2();
                loader.Show();
                
            }
            else if (txtuserName.Text != "" && txtPassword.Text == "4321")
            {
                passer1 = txtuserName.Text;
                this.Hide();
                Form3 login = new Form3();
                login.Show();
            }
            else if (txtuserName.Text == "Pharma" && txtPassword.Text == "1111")
            {
                this.Hide();
                Form10 loader = new Form10();
                loader.Show();
            }
            else if (txtuserName.Text == "" && txtPassword.Text == "")
            {
                MessageBox.Show("Username and Password Expected", "Pharmacy Management System");
            }
            else if ((txtuserName.Text != "user" && txtPassword.Text != "4321") || (txtuserName.Text != "admin" && txtPassword.Text != "1234"))
            {
                MessageBox.Show("Username and Password Wrong", "Pharmacy Management System");

            }
        }

            private void btnsignUp_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form4 login = new Form4();
            login.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            passer2 = txtuserName.Text; 
        }

        public void txtPassword_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
