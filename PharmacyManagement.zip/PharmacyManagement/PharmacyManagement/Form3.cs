﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PharmacyManagement
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
            lblUserPage.Text = " User with Id: " + Form1.passer1;
        }

        private void btnBack_Click(object sender, EventArgs e)
        {

                this.Hide();
                Form1 loader = new Form1();
                loader.Show();
            
        }

        private void lblUserPage_Click(object sender, EventArgs e)
        {
           
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            
            SqlConnection conn = new SqlConnection(@"Data Source=DESKTOP-0HDH5VS\SQLEXPRESS;Initial Catalog=Pharamcy;Integrated Security=True");
            conn.Open();
            string sqlQ = "select * from client where ClientId=1" ;
            SqlCommand sqlcmd = new SqlCommand(sqlQ, conn);
            sqlcmd.ExecuteNonQuery();
            conn.Close();
        }

        private void dataGridViewUser_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }
    }
}
