﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PharmacyManagement
{
    class Medicine
    {
        public int LotNo { get; set; }
        public string MFDate { get; set; }        public string EXPDate { get; set; }
        public string TabletName { get; set; }
        public string Dosage { get; set; }
        public string Accesibility { get; set; }
        public int Supplier { get; set; }
         
    }
}
